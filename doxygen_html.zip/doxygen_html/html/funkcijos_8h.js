var funkcijos_8h =
[
    [ "generuotiFaila", "funkcijos_8h.html#ab39cd0a4ded55af66c3ae8357481996e", null ],
    [ "irasytiRezultatusReadme", "funkcijos_8h.html#a6aacf613442995c77b74fbe55d14daf9", null ],
    [ "rodytiRezultatus", "funkcijos_8h.html#affdcdc144f48a94095829a9a54136d29", null ],
    [ "skaitytiIsFailo", "funkcijos_8h.html#a3557d6942e3893615874bf061ea31076", null ],
    [ "skirstytiStrategija1", "funkcijos_8h.html#ae81514a326c9f0c3aa379fb46ce87850", null ],
    [ "skirstytiStrategija2", "funkcijos_8h.html#a920350cca4f433fd01252b2ac5f6ac8f", null ],
    [ "skirstytiStrategija3", "funkcijos_8h.html#a29fd61de3daa04b55d77c602b414e17c", null ]
];