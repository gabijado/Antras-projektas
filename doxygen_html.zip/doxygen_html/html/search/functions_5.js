var searchData=
[
  ['rodytirezultatus_0',['rodytiRezultatus',['../funkcijos_8cpp.html#a4fae4c830f4fc67be74eeb6aee08bbfa',1,'rodytiRezultatus(vector&lt; Studentas &gt; &amp;studentai):&#160;funkcijos.cpp'],['../funkcijos_8h.html#affdcdc144f48a94095829a9a54136d29',1,'rodytiRezultatus(std::vector&lt; Studentas &gt; &amp;studentai):&#160;funkcijos.h']]]
];
