var searchData=
[
  ['irasytirezultatusreadme_0',['irasytiRezultatusReadme',['../funkcijos_8cpp.html#aed3172c317e0abd00b7180c84e33340a',1,'irasytiRezultatusReadme(double v_read, double v_split, double v_write, double l_read, double l_split, double l_write, const string &amp;failo_pav):&#160;funkcijos.cpp'],['../funkcijos_8h.html#a6aacf613442995c77b74fbe55d14daf9',1,'irasytiRezultatusReadme(double v_read, double v_split, double v_write, double l_read, double l_split, double l_write, const std::string &amp;failo_pav):&#160;funkcijos.h']]]
];
