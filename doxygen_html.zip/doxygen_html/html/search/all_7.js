var searchData=
[
  ['pavarde_0',['pavarde',['../class_zmogus.html#a24b5b4208f386916dc5c1ccf006bdedf',1,'Zmogus']]],
  ['pavarde_5f_1',['pavarde_',['../class_zmogus.html#a85cd6103a5f887059263d15413a3f081',1,'Zmogus']]]
];
